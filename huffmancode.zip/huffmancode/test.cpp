#include "huffmancode.h"

using namespace std;

int main() {
    string str = "hello world";
    HuffmanCode hc(int(str.size() + 5), str);
    hc.view();
}