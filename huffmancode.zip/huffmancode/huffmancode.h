#include<iostream>
#include<map>
#include<queue>
#include<vector>

using namespace std;

class HuffmanCode {
    protected:
        struct HuffmanNode {
            char ch;
            int fre;
            HuffmanNode *left, *right;
        };
        struct forpq_node {
            int fre;
            HuffmanNode *treeNode;
            
            bool operator< (const forpq_node other) const {
                return fre > other.fre;
            }
        };
        HuffmanNode *nodePool;
        vector<bool> code;
        HuffmanNode *root;
        void printHuffmancode();
        void viewHuffman(HuffmanNode *root, int depth);
    public:
        HuffmanCode(int cap, string str);
        ~HuffmanCode();
        void view() {
            viewHuffman(root, 0);
        }
};

HuffmanCode :: HuffmanCode(int cap, string str) {
    nodePool = new HuffmanNode[cap];
    int size = 0;
    map<char, int> count;
    for (char ch : str) {
        count[ch]++;
    }

    priority_queue<forpq_node> minHeap;
    for (auto [ch, fre] : count) {
        HuffmanNode leaf = {ch, fre, nullptr, nullptr};
        nodePool[++size] = leaf;
        minHeap.push({fre, &nodePool[size]});
    }

    while (minHeap.size() > 1) {
        auto a = minHeap.top(); minHeap.pop();
        auto b = minHeap.top(); minHeap.pop();
        nodePool[++size] = {
            '*', a.fre + b.fre, a.treeNode, b.treeNode
        };
        minHeap.push({a.fre + b.fre, &nodePool[size]});
    }
    root = minHeap.top().treeNode;
    minHeap.pop();
}

HuffmanCode :: ~HuffmanCode() {
    delete[] nodePool;
}

void HuffmanCode :: printHuffmancode() {
    for (auto it : code) cout << it;
}

void HuffmanCode :: viewHuffman(HuffmanNode *root, int depth) {
    if (root -> ch != '*') {
        cout << root -> ch << ' ' << depth << ' ';
        printHuffmancode();
        cout << '\n';
    }
    if (root -> left != nullptr) {
        code.push_back(0);
        viewHuffman(root -> left, depth + 1);
        code.pop_back();
    }
    if (root -> right != nullptr) {
        code.push_back(1);
        viewHuffman(root -> right, depth + 1);
        code.pop_back();
    }
}